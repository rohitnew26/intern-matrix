import React from "react";
import ProfileSettings from "./ProfileSettings";

// Use the richer ProfileSettings UI inside the existing MyProfile tab
export default function MyProfile() {
  return <ProfileSettings />;
}
